import { TestBed, async, inject } from '@angular/core/testing';

import { XyzGuard } from './xyz.guard';

describe('XyzGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [XyzGuard]
    });
  });

  it('should ...', inject([XyzGuard], (guard: XyzGuard) => {
    expect(guard).toBeTruthy();
  }));
});
