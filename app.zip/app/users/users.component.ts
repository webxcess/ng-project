import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor(private dataService: DataService) { }
  customerList: any;
  ngOnInit() {
    this.dataService.getAllCandidates().subscribe(
      (data:any) => {      
            //console.log(data);
          this.customerList = data;
        },
      (err : HttpErrorResponse)=>{
        
       console.log("Error in api responce");
      }
      
      );
  }

}
