import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin1',
  templateUrl: './admin1.component.html',
  styleUrls: ['./admin1.component.css']
})
export class Admin1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
