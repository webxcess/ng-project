import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { ProductsModule } from './products/products.module';
import { ChildModModule } from './child-mod/child-mod.module';

import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { HeaderComponent } from './header/header.component';
import { EditComponent } from './edit/edit.component';
import { EmpComponent } from './emp/emp.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';





@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    AddCustomerComponent,
    HeaderComponent,
    EditComponent,
    EmpComponent,
    LoginComponent,
    DashboardComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserModule,       
    HttpClientModule,
    ProductsModule,
    FormsModule,
    ChildModModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
