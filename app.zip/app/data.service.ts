import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  
  baseUrl: string = 'http://localhost/crud/api';

  constructor(private http: HttpClient) { }

  userAuthentication(data:any){ 
    
       
     let headers = new HttpHeaders({'Content-Type': 'text/plain' });
     let options = {
         headers: headers
     }
     
     return this.http.post(this.baseUrl+'/login', data, options);
   }

  getAllCandidates() {
          return this.http.get(this.baseUrl + '/view');
  }

  createUser(data:any) {
    
    let headers = new HttpHeaders({'Content-Type': 'text/plain' });
    let options = {
        headers: headers

    }    
    return this.http.post(this.baseUrl + '/add',data,options);
  }

  getUserById(id: number) {
    return this.http.get(this.baseUrl + '/view/' + id);
  }
  
  

  updateUser(user:any) {
    let headers = new HttpHeaders({'Content-Type': 'text/plain' });
    let options = {
        headers: headers
    } 
    return this.http.post(this.baseUrl + '/update/' + user.id, user,options);
  }

  deleteUser(id) {
    return this.http.delete(this.baseUrl + '/delete/' + id);
  }

  
}
