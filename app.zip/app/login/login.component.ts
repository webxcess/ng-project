import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 // errorMsg :any;
 isLoginError : boolean = false;
 loginForm: FormGroup;
 submitted = false;
 loading:boolean=false;

  constructor(private formBuilder: FormBuilder,private userService :DataService,private router: Router) {

   }
 
  ngOnInit() {
    if(localStorage.getItem('userData') != null){    
      this.router.navigate(['/dashboard']);
    }

    
	this.loginForm = this.formBuilder.group({ 
    email: ["", Validators.required], 
    password: ["", Validators.required],      
      
  });
      
  }
  get f() { return this.loginForm.controls; }

  onSubmit(){ 
    
    this.submitted = true;
    //this.loading = true; 
    // stop here if form is invalid
    if (this.loginForm.invalid) {
     
        return;

    }   
    console.log(this.loginForm.value);
      
    this.userService.userAuthentication(this.loginForm.value).subscribe((data : any)=>{

     
     if(data.result==false){
       this.isLoginError = true;
     }else{       
        //console.log(data.result[0]);   
        localStorage.setItem('userData',JSON.stringify(data.result[0]) );
        this.router.navigate(['/dashboard']);
     }
     

    },
    (err : HttpErrorResponse)=>{
      this.isLoginError = true;

    }


    );
  }

}
