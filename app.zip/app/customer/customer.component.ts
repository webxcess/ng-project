import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { DataService } from '../data.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,private dataService: DataService) { }
  title = 'ng-project';
  customerList: any;

  isSuccessMsg : boolean = false; 
  isCusSuccessDel : boolean = false;  
  myForm: FormGroup;
  submitted = false;

  ngOnInit() {
    
    this.dataService.getAllCandidates().subscribe(
      (data:any) => {      
            console.log(data);
          this.customerList = data;
        },
      (err : HttpErrorResponse)=>{
        
       console.log("Error in api responce");
      }
      
      );

      this.myForm = this.formBuilder.group({
        name: ['', Validators.required],
        password: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        phone: ['', Validators.required],
       
    });
  }

 get f() { return this.myForm.controls; }


 onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.myForm.invalid) {return;}

  
 console.log(this.myForm.value);





 alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.myForm.value))
 
  this.dataService.createUser(this.myForm.value).subscribe((data : any)=>{        
        this.isSuccessMsg = true;
       // this.myForm.reset();      
        setTimeout(() => this.isSuccessMsg = false, 3000);
        this.refreshData(); 
        this.myForm.reset();
        this.submitted = false;      
                  },
        (err : HttpErrorResponse)=>{
          console.log(err);
        }
        );
}

 

  private refreshData() {
    this.dataService.getAllCandidates().subscribe(
      (data:any) => {          
          this.customerList = data;
		  
        },
      (err : HttpErrorResponse)=>{        
       console.log(err);
      }
      
      );
}

deleteCustomer(id){ 
 
  if(confirm("Are you sure to delete record! ")) {
    this.dataService.deleteUser(id).subscribe((data : any)=>{     
    this.isCusSuccessDel = true;   
    setTimeout(() => this.isCusSuccessDel = false, 1000);      
    this.refreshData();  
   },
   (err : HttpErrorResponse)=>{ console.log(err); }
   );
  }else{
    return false;
  }    
}

}
