import { TestBed, async, inject } from '@angular/core/testing';

import { SaasGuard } from './saas.guard';

describe('SaasGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SaasGuard]
    });
  });

  it('should ...', inject([SaasGuard], (guard: SaasGuard) => {
    expect(guard).toBeTruthy();
  }));
});
