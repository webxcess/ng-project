import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kunal',
  templateUrl: './kunal.component.html',
  styleUrls: ['./kunal.component.css']
})
export class KunalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  FirstName:string = "Kunal";
  LastName:string = "Sinha";
  FullName:string;

  fnDisplayFullName() 
  {
    this.FirstName = this.FirstName + " " + this.LastName
  }

  message:string="Data from parent coomponent";

  receiveMessage($event) {
    this.message = $event;
  }

}
