import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

cs2:string="Data share by paraent to child Demo1";
imgurl:string="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png";

message:string="Data from parent";

  receiveMessage(event) {
    this.message = event
  }


}
