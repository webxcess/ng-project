import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cs2Component } from './cs2.component';

@NgModule({
  declarations: [Cs2Component],
  imports: [
    CommonModule
  ]
})
export class Cs2Module { }
