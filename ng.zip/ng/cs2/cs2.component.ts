import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cs2',
  templateUrl: './cs2.component.html',
  styleUrls: ['./cs2.component.css']
})
export class Cs2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
