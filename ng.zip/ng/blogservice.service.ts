import { Injectable } from '@angular/core';
import { HttpClient} from  '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BlogserviceService {

  constructor(private ht:HttpClient) { }

  getBlog(){
    return this.ht.get('https://jsonplaceholder.typicode.com/posts');
  }

 

}
