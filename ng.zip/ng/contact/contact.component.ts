import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ConditionalExpr } from '@angular/compiler';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private dataservice:DataService,private formBuilder:FormBuilder) { }
  myForm: FormGroup;
  mydata:any;
  
  name1="chandan"
  ngOnInit() {
    this.myForm = this.formBuilder.group({
      name: [''],
      email: [''],      
      phone: ['', [Validators.required,]],
     
  });
  }
  formSubmit(){
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.myForm.value))

  }

  abc(event){
    let name=event.target.first_name.value;
    let email=event.target.email.value;
    let phone=event.target.phone.value;
    console.log(name);
    console.log(email);
    console.log(phone);
    

    //...

  }

  onSubmit(event){
    
    // let name=event.target.name.value;
    // let email=event.target.email.value;
    // let phone=event.target.phone.value;
    
    // console.log(phone);

    // this.mydata={
    //       "name":name,
    //       "email":email,
    //       "dob":phone,
    //       "zender":"M",
    // }
    // //console.log(this.mydata);

    // this.dataservice.createUser(this.mydata).subscribe((data)=>{
    //   console.log(data);
    // })

    console.log(event);

  }




  // mydata:string="Data from cantact page";
   



}
