import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'math'
})
export class MathPipe implements PipeTransform {

  transform(base: number, exponent: number): number {
    return Math.pow(base, exponent);
 }

}
