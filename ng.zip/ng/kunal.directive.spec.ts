import { KunalDirective } from './kunal.directive';

describe('KunalDirective', () => {
  it('should create an instance', () => {
    const directive = new KunalDirective();
    expect(directive).toBeTruthy();
  });
});
