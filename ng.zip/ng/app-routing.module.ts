import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { DemoComponent } from './demo/demo.component';
import { HistoryComponent } from './history/history.component';
import { CareersComponent } from './careers/careers.component';
import { LocationComponent } from './location/location.component';
import { MydirComponent } from './mydir/mydir.component';
import { KunalComponent } from './kunal/kunal.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { SimpleFormComponent } from './simple-form/simple-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { TempFormComponent } from './temp-form/temp-form.component';
import { CustomerComponent } from './customer/customer.component';
import { PipesComponent } from './pipes/pipes.component';
import { Cs2Component } from './cs2/cs2.component';

const routes: Routes = [
  { path: '', component: HomeComponent }, 
  { path: 'cs2', component: Cs2Component }, 
  { path: 'pipes', component: PipesComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'demo', component: DemoComponent },
  { path: 'dir-demo', component: MydirComponent },
  { path: 'kunal', component: KunalComponent },
  { path: 'chart', component: PieChartComponent },
  { path: 'simple-form', component: SimpleFormComponent },
  { path: 'reactive', component: ReactiveFormComponent },
  { path: 'template', component: TempFormComponent },
  { path: 'contact', component: ContactComponent ,
      children:[
        { path: 'history/:id', component: HistoryComponent },
      
      ]
    },
  { path: 'about', component: AboutComponent,children:[
      { path: 'location/:id', component: LocationComponent },
      { path: 'careers', component: CareersComponent }   

    ] } 
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
