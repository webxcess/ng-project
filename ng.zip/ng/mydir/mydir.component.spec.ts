import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MydirComponent } from './mydir.component';

describe('MydirComponent', () => {
  let component: MydirComponent;
  let fixture: ComponentFixture<MydirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MydirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MydirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
