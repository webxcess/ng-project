import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  message:string;
  con:boolean=false;
  borderStyle = '1px solid black';
  alertStyles = {
    'color': 'red',
    'font-weight': 'bold',
    'borderBottom': this.borderStyle
  };
  public c = "blue2";
  user_id:any=3;

  receiveMessage($event) {
    this.message = $event
  }

}
