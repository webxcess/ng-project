import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {

    charts: Array<{
        title: string,
        type: string,
        data: Array<Array<string | number | {}>>,
        roles: Array<{ type: string, role: string, index?: number }>,
        columnNames?: Array<string>,
        options?: {}
      }> = [];
  aa:string;

  constructor() { 
    this.charts.push({
      title: 'Styled Line Chart',
      type: 'LineChart',
      columnNames: ['Element', 'Jobs'],
      roles: [
        { type: 'number', role: 'interval' },
        { type: 'number', role: 'interval' },
        { type: 'string', role: 'annotation' },
        { type: 'string', role: 'annotationText' },
        { type: 'boolean', role: 'certainty' }
      ],
      data: [
        ['January', 10, null, null, null, 'Completed', true],
        ['February', 11, null, null, null, 'Completed', true],
        ['March', 6, null, null, null, 'Completed', true],
        ['April', 10, null, null,  null, 'Completed', true],
      ]
    });


  }
  

  
  ngOnInit() {
    
  }
 // birthday = new Date(1988, 3, 15); // April 15, 1988
 //today: number = Date.now();

  value="Anand";
  today = new Date();
  name="Anit";

}
