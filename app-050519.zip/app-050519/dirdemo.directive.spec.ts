import { DirdemoDirective } from './dirdemo.directive';

describe('DirdemoDirective', () => {
  it('should create an instance', () => {
    const directive = new DirdemoDirective();
    expect(directive).toBeTruthy();
  });
});
