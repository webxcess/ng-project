import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[customdie]'
})
export class DirdemoDirective {

  constructor(private ele:ElementRef) {
    ele.nativeElement.style.backgroundColor = 'yellow';

   }

}
