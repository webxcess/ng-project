import { Cs2Directive } from './cs2.directive';

describe('Cs2Directive', () => {
  it('should create an instance', () => {
    const directive = new Cs2Directive();
    expect(directive).toBeTruthy();
  });
});
