import { DemoPipePipe } from './demo-pipe.pipe';

describe('DemoPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DemoPipePipe();
    expect(pipe).toBeTruthy();
  });
});
