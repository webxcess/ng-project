import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[xyz]'
})
export class MydirDirective {

  constructor(private el:ElementRef) {
    
    el.nativeElement.style.backgroundColor = 'blue';

   }
   @HostListener('click') doExtra(){
    console.log("hello");
   }
   @HostListener('mouseenter') doExtra2(){
    console.log("mouce has entered");
  }
  @HostListener('mouseleave') doExtra3(){
    console.log("mouce has leaved");
  }

}
