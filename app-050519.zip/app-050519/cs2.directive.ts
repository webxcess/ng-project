import { Directive, ElementRef, HostListener,Renderer  } from '@angular/core';

@Directive({
  selector: '[dddd]'
})
export class Cs2Directive {

  constructor(private el:ElementRef,private renderer: Renderer) {

    this.el.nativeElement.style.backgroundColor = 'green';
    this.el.nativeElement.style.fontWeight = 'bold';
   }

   

    @HostListener('mouseover') onMouseOver() {
      let part = this.el.nativeElement.querySelector('.card-text');
      this.renderer.setElementStyle(part, 'display', 'block');

     
    
    }
  
    @HostListener('mouseout') onMouseOut() {
      let part = this.el.nativeElement.querySelector('.card-text');
      this.renderer.setElementStyle(part, 'display', 'none');

    }




}
