import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { KunalModule } from './kunal.module';

import { OrderModule } from './order/order.module';

import { Cs2Module } from './cs2/cs2.module';

import { CustomerModule } from './customer.module';
import { DummyModule } from './dummy.module';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';


import { SidebarComponent } from './sidebar/sidebar.component';
import { ChildComponent } from './child/child.component';
import { ParentComponent } from './parent/parent.component';
import { DemoComponent } from './demo/demo.component';
import { Demo1Component } from './demo1/demo1.component';
import { Demo2Component } from './demo2/demo2.component';
import { HighlightDirective } from './highlight.directive';
import { MydirDirective } from './mydir.directive';
import { HistoryComponent } from './history/history.component';
import { CareersComponent } from './careers/careers.component';
import { LocationComponent } from './location/location.component';
import { LoginComponent } from './auth/login/login.component';
import { MydirComponent } from './mydir/mydir.component';
import { DirdemoDirective } from './dirdemo.directive';
import { KunalComponent } from './kunal/kunal.component';
import { KunalDirective } from './kunal.directive';
import { PieChartComponent } from './pie-chart/pie-chart.component';

import { PowerPipe } from './power.pipe';
import { MathPipe } from './math.pipe';
import { DemoPipePipe } from './demo-pipe.pipe';
import { SimpleFormComponent } from './simple-form/simple-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { TempFormComponent } from './temp-form/temp-form.component';




import { Cs2Directive } from './cs2.directive';
import { CustompipePipe } from './custompipe.pipe';







@NgModule({
  declarations: [
    
    AppComponent,
    FirstComponent,
    SecondComponent,
    HomeComponent,
    AboutComponent,
    
    
    SidebarComponent,
    ChildComponent,
    ParentComponent,
    DemoComponent,
    Demo1Component,
    Demo2Component,
    HighlightDirective,
    MydirDirective,
    HistoryComponent,
    CareersComponent,
    LocationComponent,
    LoginComponent,
    MydirComponent,
    DirdemoDirective,
    KunalComponent,
    KunalDirective,    
    PowerPipe,
    MathPipe,
    DemoPipePipe,
    SimpleFormComponent,
    ReactiveFormComponent,
    TempFormComponent,
    Cs2Directive,
    PieChartComponent,
    CustompipePipe
    
  ],
  imports: [
    BrowserModule,
    CustomerModule,
    KunalModule,      
    HttpClientModule,    
    DummyModule,
    Cs2Module,
    AppRoutingModule,
    OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
