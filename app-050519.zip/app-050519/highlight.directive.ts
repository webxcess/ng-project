import { Directive, ElementRef  } from '@angular/core';

@Directive({
  selector: '[Highlight]'
})
export class HighlightDirective {

  constructor(ele: ElementRef) {
    ele.nativeElement.style.backgroundColor = 'yellow';
   }

}
