import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

  products=[
    {
      "name":"produuct1",
      "imageurl":"https://www.w3schools.com/html/pic_trulli.jpg", 
      "price":"80" 
    },
    
    {
      "name":"product2",
      "imageurl":"https://www.w3schools.com/html/pic_trulli.jpg", 
      "price":"70" 
    },
    
    {
      "name":"product3",
      "imageurl":"https://www.w3schools.com/html/pic_trulli.jpg", 
      "price":"60" 
    },
    {
      "name":"product4",
      "imageurl":"https://www.w3schools.com/html/pic_trulli.jpg", 
      "price":"500" 
    }
    
    
    ]
    





}
