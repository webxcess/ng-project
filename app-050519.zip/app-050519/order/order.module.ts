import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderListComponent } from './order-list/order-list.component';
import { ReactiveFormsModule,FormsModule  } from '@angular/forms';
import { HeaderComponent } from '../order/header/header.component';
import { FooterComponent } from '../order/footer/footer.component';
import {  RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    OrderListComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    CommonModule,RouterModule
  ],
  exports: [
    OrderListComponent,
    ReactiveFormsModule,
    FormsModule,
    HeaderComponent,
    FooterComponent
  ]
})
export class OrderModule { }
