import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydir',
  templateUrl: './mydir.component.html',
  styleUrls: ['./mydir.component.css']
})
export class MydirComponent implements OnInit {

  constructor() { }
a:any;
  ngOnInit() {
this.a=false
this.condition=this.a;
  }
  
  show:number=2;

 status:String="green";
condition:boolean=true;
  responce:string="abcd";
  borderStyle = '1px solid black';
  alertStyles = {
    'color': 'red',
    'font-size':'18px',
    'font-weight': 'bold',
    'borderBottom': this.borderStyle
  };
  public color = "blue";
}


