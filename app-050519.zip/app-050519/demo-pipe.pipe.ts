import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'demoPipe'
})
export class DemoPipePipe implements PipeTransform {

  transform(base: number, exponent: number): number {
    return Math.pow(base, exponent);
 }

}
