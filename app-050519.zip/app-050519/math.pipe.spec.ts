import { MathPipe } from './math.pipe';

describe('MathPipe', () => {
  it('create an instance', () => {
    const pipe = new MathPipe();
    expect(pipe).toBeTruthy();
  });
});
