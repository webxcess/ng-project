import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  myForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
      this.myForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          file: ['', Validators.required],
         
      });
  }

     // convenience getter for easy access to form fields
 // get f() { return this.myForm.controls; }
  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.myForm.invalid) {return;}
     console.log(this.myForm.value);
     //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.myForm.value))
     let fdata =this.myForm.value;
     let f = fdata.file;
     alert(fdata.file);
  }
}