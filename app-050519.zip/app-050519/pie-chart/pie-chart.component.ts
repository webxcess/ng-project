import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {

   
  

  
  ngOnInit() {
    
  }
 // birthday = new Date(1988, 3, 15); // April 15, 1988
 //today: number = Date.now();

  value="Anand";
  today = new Date();
  name="Anit";
  mynumber=2;

}
