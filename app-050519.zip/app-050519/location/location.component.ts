import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute,Params} from '@angular/router';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {

  constructor(private route:Router,private abc:ActivatedRoute) { }
  location_name:any;
  location_add:any;
  location_id:any;
  ngOnInit() {
   // this.location_name=this.abc.snapshot.params['id']; // By snapshot
     // By snapshot

   this.abc.params.subscribe(
    (param:Params)=>{
      this.location_id=param['id'];
    }
  ) 
  
    
  }
  gotoCarrers(){
    this.route.navigate(['about/careers']);
  }
  

}
