import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactComponent } from './contact/contact.component';
import { AppRoutingModule } from './app-routing.module';
import { OrderModule } from './order/order.module';


@NgModule({
  declarations: [
    ContactComponent,
  ],
  imports: [
    CommonModule,  
    AppRoutingModule,
    OrderModule
  ]
})
export class DummyModule { 


}
