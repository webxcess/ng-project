import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute,Params} from '@angular/router';


@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {

  constructor(private route:Router,private rt:ActivatedRoute) { }
  page_id:string;
  ngOnInit() {
   //this.page_id=this.rt.snapshot.params['id'];// by snapshop
   console.log(this.rt.params);
   this.rt.params.subscribe(
     (param:Params)=>{
       this.page_id=param['id'];
     }
   ) 
  }
   
  gotoHistorypage(){
    this.route.navigate(['contact/careers']);

  }

}
