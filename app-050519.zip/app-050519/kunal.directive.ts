import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appKunal]'
})
export class KunalDirective {

  constructor(private el : ElementRef) { 
    this.el.nativeElement.style.backgroundColor = 'blue';
    this.el.nativeElement.style.fontWeight = 'bold';
    
  }

  @HostListener('mouseenter') acb(){
  alert("Hello Kunal");
  }

}
