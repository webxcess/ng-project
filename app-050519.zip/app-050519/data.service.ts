import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders} from  '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private  httpClient:  HttpClient) { }
  
  getInfo(){
    return this.httpClient.get('https://jsonplaceholder.typicode.com/posts');
  }


  createUser(data:any) {      
    let headers = new HttpHeaders({'Content-Type': 'text/plain' });
    let options = {
        headers: headers
    }    
    return this.httpClient.post('http://localhost/crud/api/add', data, options);
  }
}
