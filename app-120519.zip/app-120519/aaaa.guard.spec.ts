import { TestBed, async, inject } from '@angular/core/testing';

import { AaaaGuard } from './aaaa.guard';

describe('AaaaGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AaaaGuard]
    });
  });

  it('should ...', inject([AaaaGuard], (guard: AaaaGuard) => {
    expect(guard).toBeTruthy();
  }));
});
