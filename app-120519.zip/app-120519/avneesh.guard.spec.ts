import { TestBed, async, inject } from '@angular/core/testing';

import { AvneeshGuard } from './avneesh.guard';

describe('AvneeshGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AvneeshGuard]
    });
  });

  it('should ...', inject([AvneeshGuard], (guard: AvneeshGuard) => {
    expect(guard).toBeTruthy();
  }));
});
