import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChildcompComponent } from '../child-mod/childcomp/childcomp.component';

@NgModule({
  declarations: [ChildcompComponent],
  imports: [
    CommonModule
  ]
})
export class ChildModModule { }
