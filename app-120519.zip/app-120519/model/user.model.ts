export class User {

  id: number;
  name: string;
  zender: string;
  dob:string;
  email: string;
}
