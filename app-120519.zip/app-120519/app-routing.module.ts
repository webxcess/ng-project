import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { EditComponent } from './edit/edit.component';
import { EmpComponent } from './emp/emp.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import { ProductComponent } from './product/product.component';
import { ChildcompComponent } from './child-mod/childcomp/childcomp.component';

const routes: Routes = [
  { "path":"",loadChildren:'./auth/auth.module#AuthModule'},
  { "path":"admin",loadChildren:'./cs2/cs2.module#Cs2Module'},
  { "path":"dashboard",component:DashboardComponent , canActivate : [AuthGuard] },
  { "path":"add",component:CustomerComponent, canActivate : [AuthGuard]  },
  { "path":"add-emp",component:AddCustomerComponent , canActivate : [AuthGuard] },
  { "path":"edit/:id",component:EditComponent , canActivate : [AuthGuard] },
  { "path":"emp-list",component:EmpComponent , canActivate : [AuthGuard] },
  { "path":"products",component:ProductComponent },
  { "path":"childCom",component:ChildcompComponent }
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
