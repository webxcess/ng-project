import { Component, OnInit } from '@angular/core';
import { NewdataService } from '../newdata.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  constructor (private scr2:NewdataService) { }
emplist:any;

  ngOnInit() {
    console.log(this.scr2.getAllEmp());
    this.scr2.getAllEmp().subscribe(
      (data:any) => {          
        console.log(data);
          this.emplist = data;
        },
      (err : HttpErrorResponse)=>{
        
       console.log("Error in api responce");
      }
      
      );
  }

}
