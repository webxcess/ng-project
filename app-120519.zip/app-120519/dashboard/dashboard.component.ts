import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { DataService } from '../data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,private dataService: DataService) { }
  customerList: any;
  user:any;
  dataByChild:string;
  ngOnInit() {
    //this.user = localStorage.getItem('userData');
    this.user = JSON.parse(localStorage.getItem('userData'));
    this.dataService.getAllCandidates().subscribe(
      (data:any) => {      
            //console.log(data);
          this.customerList = data;
        },
      (err : HttpErrorResponse)=>{
        
       console.log("Error in api responce");
      }
      
      );
  }
 

  receiveMsg(event){
     this.dataByChild=event;

  }

}
