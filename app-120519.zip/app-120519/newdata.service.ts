import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class NewdataService {

  constructor(private http: HttpClient) { }
  getAllEmp(){
    return this.http.get('http://localhost/crud/api/view');
  }
}
