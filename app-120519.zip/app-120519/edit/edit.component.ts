import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { DataService } from '../data.service';
import { Router,ActivatedRoute,Params} from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private location: Location,private formBuilder: FormBuilder,private dataService: DataService,private route:Router,private active:ActivatedRoute) { }

  myForm: FormGroup;
  submitted = false;
  singleCus:any;
  isSuccessMsg : boolean = false; 
  user_id:any;

  ngOnInit() {

    this.user_id=this.active.snapshot.params['id']; 
    
    
    this.dataService.getUserById(this.user_id).subscribe(
      (data:any) => {
        
          this.singleCus = data[0];
          
          this.myForm = this.formBuilder.group({
            id: [this.singleCus.id],
            name: [this.singleCus.name, Validators.required],
            password: [this.singleCus.password, Validators.required],
            email: [this.singleCus.email, [Validators.required, Validators.email]],
            phone: [this.singleCus.phone, Validators.required],
           
        });
       
        },
      (err : HttpErrorResponse)=>{
        
        console.log(err);
      }
      
      );

     
  }


  get f() { return this.myForm.controls; }
 onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.myForm.invalid) {return;}
 console.log(this.myForm.value);

 
  this.dataService.updateUser(this.myForm.value).subscribe((data : any)=>{        
        this.isSuccessMsg = true;
       // this.myForm.reset();      
        setTimeout(() => this.isSuccessMsg = false, 3000);                   
                  },
        (err : HttpErrorResponse)=>{
          console.log(err);
        }
        );
}

back(){
  this.location.back();
}

}
